Load up order

1. ServerApplication.exe
2. ClientApplication.exe




camera controls for ClientApplication:

Left Arrow - 			Move Camera Left
RIght Arrow - 			Move Camera Right
Up Arrow - 			Move Camera Up
Down Arrow - 			Move Camera Down

Page Up - 			Zoom in
Page Down - 			Zoom Out

Mouse Right Click + Drag - 	Look around