Controls:



IN RACE:
Right Trigger - shoot a rope to swing
Right Bumper - retract rope and gain a speed boost
Right Alalog - look around with camera

IN MENU:
(Multiplayer - A to join with another controller)

Left Analog - navigate menu
A - select option